﻿using Microsoft.Extensions.Configuration;
using Serversides_Paginations_Practical.Models;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

public class CourseDataAccess
{
    private readonly string connectionString;

    public CourseDataAccess(IConfiguration configuration)
    {
        connectionString = configuration.GetConnectionString("DefaultConnection");

    }

    public void InsertCourse(Course course)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            SqlCommand command = new SqlCommand("ManageCourses", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Action", "INSERT");
            command.Parameters.AddWithValue("@Name", course.Name);
            command.Parameters.AddWithValue("@Description", course.Description);

            connection.Open();
            command.ExecuteNonQuery();
        }
    }

    public void UpdateCourse(Course course)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            SqlCommand command = new SqlCommand("ManageCourses", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Action", "UPDATE");
            command.Parameters.AddWithValue("@Id", course.Id);
            command.Parameters.AddWithValue("@Name", course.Name);
            command.Parameters.AddWithValue("@Description", course.Description);

            connection.Open();
            command.ExecuteNonQuery();
        }
    }

    public void DeleteCourse(int id)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            SqlCommand command = new SqlCommand("ManageCourses", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Action", "DELETE");
            command.Parameters.AddWithValue("@Id", id);

            connection.Open();
            command.ExecuteNonQuery();
        }
    }

    public List<Course> GetCourses()
    {
        List<Course> courses = new List<Course>();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            SqlCommand command = new SqlCommand("ManageCourses", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Action", "DISPLAY");

            connection.Open();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Course course = new Course();
                course.Id = (int)reader["Id"];
                course.Name = (string)reader["Name"];
                course.Description = (string)reader["Description"];

                courses.Add(course);
            }
        }

        return courses;
    }
}