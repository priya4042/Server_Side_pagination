﻿using Microsoft.Extensions.Configuration;
using Serversides_Paginations_Practical.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

public class StudentDataAccess
{
    private readonly string connectionString;

    public StudentDataAccess(IConfiguration configuration)
    {
        connectionString = configuration.GetConnectionString("DefaultConnection");

    }

    public void InsertStudent(Students student)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            SqlCommand command = new SqlCommand("CreateStudent", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Name", student.Name);
            command.Parameters.AddWithValue("@Email", student.Email);
            command.Parameters.AddWithValue("@BirthDate", student.BirthDate);
            command.Parameters.AddWithValue("@Address", student.Address);
            command.Parameters.AddWithValue("@City", student.City);
            command.Parameters.AddWithValue("@Country", student.Country);
            command.Parameters.AddWithValue("@ActiveStatus", student.ActiveStatus);
            command.Parameters.AddWithValue("@Gender", student.Gender);
            command.Parameters.AddWithValue("@Course", student.Course);


            connection.Open();
            command.ExecuteNonQuery();
        }
    }

    public Students GetStudentById(int studentId)
    {
        using (var connection = new SqlConnection(connectionString))
        {
            connection.Open();

            var command = new SqlCommand("GetStudentById", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@StudentId", studentId);

            using (var reader = command.ExecuteReader())
            {
                if (reader.Read())
                {
                  
                    var student = new Students
                    {
                        Id = (int)reader["StudentId"],
                        Name = reader["Name"].ToString(),
                        Email = reader["Email"].ToString(),
                        BirthDate = (DateTime)reader["BirthDate"],
                        Address = reader["Address"].ToString(),
                        City = reader["City"].ToString(),
                        Country = reader["Country"].ToString(),
                        ActiveStatus = (bool)reader["ActiveStatus"],
                        Gender = reader["Gender"].ToString(),
                        Course = reader["Course"].ToString()
                    };

                    return student;
                }
            }
        }

        return null;
    }


    public void UpdateStudent(Students student)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            SqlCommand command = new SqlCommand("UpdateStudent", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@StudentId", student.Id);
            command.Parameters.AddWithValue("@Name", student.Name);
            command.Parameters.AddWithValue("@Email", student.Email);
            command.Parameters.AddWithValue("@BirthDate", student.BirthDate);
            command.Parameters.AddWithValue("@Address", student.Address);
            command.Parameters.AddWithValue("@City", student.City);
            command.Parameters.AddWithValue("@Country", student.Country);
            command.Parameters.AddWithValue("@ActiveStatus", student.ActiveStatus);
            command.Parameters.AddWithValue("@Gender", student.Gender);
            command.Parameters.AddWithValue("@Course", student.Course);

            connection.Open();
            command.ExecuteNonQuery();
        }
    }

    public void DeleteStudent(int id)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            SqlCommand command = new SqlCommand("DeleteStudent", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Id", id);

            connection.Open();
            command.ExecuteNonQuery();
        }
    }

    public List<Students> GetStudents(int pageSize, int pageNumber)
    {
        List<Students> students = new List<Students>();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            SqlCommand command = new SqlCommand("GetAllStudents", connection);
            command.CommandType = CommandType.StoredProcedure;

            connection.Open();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Students student = new Students();
                student.Id = (int)reader["StudentId"];
                student.Name = (string)reader["Name"];
                student.Email = (string)reader["Email"];
                student.BirthDate = (DateTime)reader["BirthDate"];
                student.Address = (string)reader["Address"];
                student.City = (string)reader["City"];
                student.Country = (string)reader["Country"];
                student.ActiveStatus = (bool)reader["ActiveStatus"];
                student.Gender = (string)reader["Gender"];

                students.Add(student);
            }
        }

        return students;
    }

    public List<Students> GetPagedStudents(int pageNumber, int pageSize)
    {
        List<Students> students = new List<Students>();

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            SqlCommand command = new SqlCommand("GetPagedStudents", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@PageNumber", pageNumber);
            command.Parameters.AddWithValue("@PageSize", pageSize);

            connection.Open();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Students student = new Students();
                student.Id = (int)reader["StudentId"];
                student.Name = (string)reader["Name"];
                student.Email = (string)reader["Email"];
                student.BirthDate = (DateTime)reader["BirthDate"];
                student.Address = (string)reader["Address"];
                student.City = (string)reader["City"];
                student.Country = (string)reader["Country"];
                student.ActiveStatus = (bool)reader["ActiveStatus"];
                student.Gender = (string)reader["Gender"];

                students.Add(student);
            }
        }

        return students;
    }
}
