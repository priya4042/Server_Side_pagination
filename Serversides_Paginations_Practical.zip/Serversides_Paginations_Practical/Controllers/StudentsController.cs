﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Serversides_Paginations_Practical.Models;
using System;
using System.Collections.Generic;

namespace Serversides_Paginations_Practical.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private readonly StudentDataAccess studentDataAccess;

        public StudentsController(IConfiguration configuration)
        {
            studentDataAccess = new StudentDataAccess(configuration);
        }

        // GET api/students
        [HttpGet("Students")]
        public IActionResult GetStudents(int pageSize, int pageNumber)
            {
            List<Students> students = studentDataAccess.GetStudents( pageSize, pageNumber);
            return Ok(students);
        }

        // POST api/students
        [HttpPost("Student")]
        public IActionResult PostStudent(Students student)
        {
            if (student.Id > 0)
            {
                studentDataAccess.UpdateStudent(student);
            }
            else
            {
                studentDataAccess.InsertStudent(student);
            }
            return Ok();
        }

         [HttpGet("{id}")]
        public IActionResult GetStudentById(int id)
        {
            var student = studentDataAccess.GetStudentById(id);

            if (student == null)
            {
                return NotFound(); 
            }

            return Ok(student); 
        }
        // PUT api/students/5
        [HttpPut("{id}")]
        public IActionResult UpdateStudent(int id, Students student)
        {
            if (id > 0)
            {
                return Ok(student);
            }
            else
            {
                return Ok();
            }
        }



        // DELETE api/students/5
        [HttpDelete("{id}")]
        public IActionResult DeleteStudent(int id)
        {
            studentDataAccess.DeleteStudent(id);
            return Ok();
        }
    }
}
